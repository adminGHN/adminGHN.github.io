print(" # __init__.py")

from flask import Flask
app = Flask(__name__)

import basic_wms.views



